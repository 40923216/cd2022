import math
 
def sysCall_init():
    print("From non-threaded Python child script, sysCall_init")
    # ???????????? cube ??, ????? global
    global cube
    # ?? script ????, ? cube ????
    cube=sim.getObject('.')
    global pos
    pos=sim.getObjectPosition(cube,-1)
    global deg, theta
    deg = math.pi/180.
    theta = 0
     
def sysCall_actuation():
    print("From non-threaded Python child script, sysCall_actuation")
    global theta
    # ?????
    theta = theta - 0.01
    # ? (pos[0]-1, pos[1]) ???, ?? 1m ??
    pos[0] = math.cos(theta)-1
    print(pos[0])
    pos[1] = math.sin(theta)
    print(pos[1])
    #pos[1]=pos[1]+0.01
    sim.setObjectPosition(cube,-1,pos)
     
def sysCall_sensing():    
    print("From non-threaded Python child script, sysCall_sensing")
def sysCall_cleanup():
    print("From non-threaded Python child script, sysCall_cleanup")
